import dev.robocode.tankroyale.botapi.Bot
import dev.robocode.tankroyale.botapi.BotInfo
import dev.robocode.tankroyale.botapi.Color
import dev.robocode.tankroyale.botapi.IBot
import dev.robocode.tankroyale.botapi.events.Condition
import dev.robocode.tankroyale.botapi.events.HitBotEvent
import dev.robocode.tankroyale.botapi.events.HitWallEvent
import dev.robocode.tankroyale.botapi.events.ScannedBotEvent


class Crazy  // Constructor, which loads the bot config file
internal constructor() : Bot(BotInfo.fromFile("Crazy.json")) {
    var movingForward = false

    // Called when a new round is started -> initialize and do some movement
    override fun run() {
        // Set colors
        bodyColor = Color.fromString("#00C800") // lime
        gunColor = Color.fromString("#009632") // green
        radarColor = Color.fromString("#006464") // dark cyan
        bulletColor = Color.fromString("#FFFF64") // yellow
        scanColor = Color.fromString("#FFC8C8") // light red


        while (isRunning) {
            // want to move ahead 40000 -- some large number
            setForward(40000.0)
            movingForward = true
            // Rodar 90
            setTurnRight(90.0)
            // At this point, we have indicated to the game that *when we do something*,
            // we will want to move ahead and turn right. That's what "set" means.
            // It is important to realize we have not done anything yet!
            // In order to actually move, we'll want to call a method that takes real time, such as
            // waitFor.
            // waitFor actually starts the action -- we start moving and turning.
            // It will not return until we have finished turning.
            waitFor(TurnCompleteCondition(this))
            // Note: We are still moving ahead now, but the turn is complete.
            // Now we'll turn the other way...
            setTurnLeft(180.0)
            // ... and wait for the turn to finish ...
            waitFor(TurnCompleteCondition(this))
            // ... then the other way ...
            setTurnRight(180.0)
            // ... and wait for that turn to finish.
            waitFor(TurnCompleteCondition(this))
            // then back to the top to do it all again.
        }
    }

    // We collided with a wall -> reverse the direction
    override fun onHitWall(e: HitWallEvent) {
        // Bounce off!
        reverseDirection()
    }

    // ReverseDirection: Switch from ahead to back & vice versa
    fun reverseDirection() {
        movingForward = if (movingForward) {
            setBack(40000.0)
            false
        } else {
            setForward(40000.0)
            true
        }
    }

    // We scanned another bot -> fire!
    override fun onScannedBot(e: ScannedBotEvent) {
        fire(1.0)
    }

    // We hit another bot -> back up!
    override fun onHitBot(e: HitBotEvent) {
        // If we're moving into the other bot, reverse!
        if (e.isRammed) {
            reverseDirection()
        }
    }

    // Condition that is triggered when the turning is complete
    class TurnCompleteCondition(private val bot: IBot) : Condition() {
        override fun test(): Boolean {
            // turn is complete when the remainder of the turn is zero
            return bot.turnRemaining == 0.0
        }
    }

    companion object {
        // The main method starts our bot
        @JvmStatic
        fun main(args: Array<String>) {
            Crazy().start()
        }
    }
}